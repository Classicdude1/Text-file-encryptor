HOW TO USE TextFileEncryptor,version 1.0

1 Go to the folder you downloaded TextFileEncryptor and open the 'dist' folder.
2 Open TextFileEncryptor.exe
3 Make sure your text file you want to encrypt is saved in the 'dist' folder.
4 You can as well enter the names of the text file you see in the 'dist' folder to test this program
NOTE:
Make sure your original text file you want to encrypt is saved in another directory to avoid losing 
any information of the text file.